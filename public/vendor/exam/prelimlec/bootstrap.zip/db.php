<?php
//YOU ARE NOT ALLOWED TO EDIT!
$accounts = [
    [
      'uname' => 'jemceu',
      'pword' => 'jemiah123',
      'fname' => 'Jemiah Del Rosario',
      'type' => 'user',
      'likes' => ['President', 'Mar Roxas', 'Leni Robredo']
    ],
    [
      'uname' => 'ealaceu',
      'pword' => 'ealyza321',
      'fname' => 'Ealyza Charmaine Valencia',
      'type' => 'user',
      'likes' => ['USA','Donald Trump']
    ],
    [
      'uname' => 'jediceu',
      'pword' => 'bargola231',
      'fname' => 'Jedi Leerey Bargola',
      'type' => 'admin',
      'likes' => ['LightSaber', 'Force','Dogs']
    ],
    [
      'uname' => 'ivanceu',
      'pword' => 'bodoso321',
      'fname' => 'Ivan Bodoso',
      'type' => 'user',
      'likes' => ['Basketball', 'Varisty']
    ],
    [
      'uname' => 'davidceu',
      'pword' => 'calalang123',
      'fname' => 'David Christian Calalang',
      'type' => 'user',
      'likes' => ['Jokes', 'Roxanne']
    ],
    [
      'uname' => 'kentceu',
      'pword' => 'kent231',
      'fname' => 'Rigel Kent Cruz',
      'type' => 'admin',
      'likes' => ['Codes']
    ],
    [
      'uname' => 'cjceu',
      'pword' => 'dc321',
      'fname' => 'Carl Joseph Dela Cruz',
      'type' => 'user',
      'likes' => ['Moustache', 'Dirty', 'Booze']
    ],
    [
      'uname' => 'alexceu',
      'pword' => 'alexespiritu123',
      'fname' => 'John Alexander Espiritu',
      'type' => 'user',
      'likes' => ['Canada']
    ],
    [
      'uname' => 'jmceu',
      'pword' => 'juanmiguel123',
      'fname' => 'Juan Miguel Guzman',
      'type' => 'admin',
      'likes' => ['Basketball']
    ],
    [
      'uname' => 'forbesceu',
      'pword' => 'forbes231',
      'fname' => 'Lawrence Ian Forbes',
      'type' => 'user',
      'likes' => []
    ],
    [
      'uname' => 'paulceu',
      'pword' => 'paulchi123',
      'fname' => 'Paul Kenneth Heyrana',
      'type' => 'user',
      'likes' => []
    ],
    [
      'uname' => 'mackieceu',
      'pword' => 'navarro321',
      'fname' => 'John Mark Navarro',
      'type' => 'admin',
      'likes' => ['Videos', 'Pictures']
    ],
    [
      'uname' => 'ralphceu',
      'pword' => 'ralphmariano123',
      'fname' => 'Ralph Jimel Mariano',
      'type' => 'user',
      'likes' => ['Choir', 'Singers']
    ],
    [
      'uname' => 'pradoceu',
      'pword' => 'daniel231',
      'fname' => 'Daniel Prado',
      'type' => 'user',
      'likes' => ['ML']
    ],
    [
      'uname' => 'stevenceu',
      'pword' => 'stevenjosh123',
      'fname' => 'Steven Josh Sarmiento',
      'type' => 'admin',
      'likes' => ['Buildings']
    ],
    [
      'uname' => 'lanceceu',
      'pword' => 'lance231',
      'fname' => 'Lance Chester Pradez',
      'type' => 'user',
      'likes' => ['EAgLe', 'Birds']
    ],
    [
      'uname' => 'meierceu',
      'pword' => 'keneth123',
      'fname' => 'Keneth Meier',
      'type' => 'user',
      'likes' => ['Cheetah', 'Sloth', 'Tarsier']
    ],
    [
      'uname' => 'gitaceu',
      'pword' => 'noel231',
      'fname' => 'John Noel Gita',
      'type' => 'admin',
      'likes' => ['Gold fish', 'Sharks', 'Dolphins']
    ],
    [
      'uname' => 'migsceu',
      'pword' => 'miguel321',
      'fname' => 'Miguel Tuazon',
      'type' => 'user',
      'likes' => ['Fish', 'Giraffe', 'Birds']
    ],
    [
      'uname' => 'shiksceu',
      'pword' => 'bolasoc123',
      'fname' => 'Raymart Bolasoc',
      'type' => 'user',
      'likes' => ['Cats', 'Dogs', 'sboob']
    ],
    [
      'uname' => 'captainamerica',
      'pword' => 'captain123',
      'fname' => 'Steve Rogers',
      'type' => 'admin',
      'likes' => ['Shield', 'Bucky']
    ],
    [
      'uname' => 'spiderman',
      'pword' => 'spiderman123',
      'fname' => 'Peter Parker',
      'type' => 'user',
      'likes' => ['Iron Suit', 'MJ']
    ],
    [
      'uname' => 'blackwidow',
      'pword' => 'natasha321',
      'fname' => 'Natasha Romanova',
      'type' => 'user',
      'likes' => ['Hulk', 'Dig Bick ']
    ],
    [
      'uname' => 'hulk',
      'pword' => 'hulkgreen123',
      'fname' => 'Bruce Banner',
      'type' => 'admin',
      'likes' => ['Smash', 'Taco']
    ],
    [
      'uname' => 'thor',
      'pword' => 'odinson123',
      'fname' => 'Thor Odinson',
      'type' => 'user',
      'likes' => ['Loki', 'Mjolnir', 'Stormbreaker']
    ],
    [
      'uname' => 'loki',
      'pword' => 'odinson321',
      'fname' => 'Loki Odinson',
      'type' => 'user',
      'likes' => ['Thor']
    ],
    [
      'uname' => 'blackpanther',
      'pword' => 'wakandaforever',
      'fname' => 'TChalla',
      'type' => 'admin',
      'likes' => ['WAKANDA', 'Titanium']
    ],
    [
      'uname' => 'antman',
      'pword' => 'antman123',
      'fname' => 'Scott Lang',
      'type' => 'user',
      'likes' => ['Wasp']
    ],
    [
      'uname' => 'doctorstrange',
      'pword' => 'timestone231',
      'fname' => 'Stephen Strange',
      'type' => 'user',
      'likes' => ['Time Stone']
    ],
    [
      'uname' => 'wintersoldier',
      'pword' => 'vibraniumarm123',
      'fname' => 'Bucky Barnes',
      'type' => 'admin',
      'likes' => ['Prostetics']
    ],
    [
      'uname' => 'scarletwitch',
      'pword' => 'wanda123',
      'fname' => 'Wanda Maximoff',
      'type' => 'user',
      'likes' => ['Jarvis', 'Vision']
    ],
    [
      'uname' => 'hawkeye',
      'pword' => 'hawkeye123',
      'fname' => 'Clint Barton',
      'type' => 'user',
      'likes' => ['Bullseye', 'Arrows', 'Daggers']
    ],
    [
      'uname' => 'falcon',
      'pword' => 'falcon321',
      'fname' => 'Sam Wilson',
      'type' => 'admin',
      'likes' => ['Birds', 'Wings', 'Drones']
    ],
    [
      'uname' => 'warmachine',
      'pword' => 'warmachinerox123',
      'fname' => 'James Rhodes',
      'type' => 'user',
      'likes' => ['Stories to tell', 'Warmachine', 'War']
    ],
    [
      'uname' => 'nickfury',
      'pword' => 'leader231',
      'fname' => 'Nick Fury',
      'type' => 'user',
      'likes' => ['An eye', 'A Cat', 'A Hair']
    ],
    [
      'uname' => 'ultronage',
      'pword' => 'fakejarvis321',
      'fname' => 'Ultron',
      'type' => 'admin',
      'likes' => ['Peace', 'on', 'Earth']
    ],
    [
      'uname' => 'captainmarvel',
      'pword' => 'strongestavenger321',
      'fname' => 'Carol Danvers',
      'type' => 'user',
      'likes' => ['Fly to the moon', 'New Haircut', 'Riley Reid']
    ],
    [
      'uname' => 'okoye',
      'pword' => 'wakanda123',
      'fname' => 'Okoye Milaje',
      'type' => 'user',
      'likes' => ['Sasha Grey']
    ],
    [
      'uname' => 'mariahill',
      'pword' => 'assistant231',
      'fname' => 'Maria Hill',
      'type' => 'admin',
      'likes' => ['Nothing']
    ],
    [
      'uname' => 'stark',
      'pword' => 'tonystark1',
      'fname' => 'Tony Stark',
      'type' => 'user',
      'likes' => ['ILOVEYOU3000', 'Ladies', 'Suits']
    ],
    [
      'uname' => 'lucifer666',
      'pword' => 'lucy12',
      'fname' => 'Lucifer Morningstar',
      'type' => 'user',
      'likes' => ['Chloe']
    ],
    [
      'uname' => 'chloedecker',
      'pword' => 'lucifergf',
      'fname' => 'Chloe Decker',
      'type' => 'admin',
      'likes' => []
    ],
    [
      'uname' => 'dommuscle',
      'pword' => 'torretto123',
      'fname' => 'Dominic Torretto',
      'type' => 'user',
      'likes' => []
    ],
    [
      'uname' => 'hobbsbuff',
      'pword' => 'luke231',
      'fname' => 'Luke Hobbs',
      'type' => 'user',
      'likes' => ['Muscles', 'Baby Oil']
    ],
    [
      'uname' => 'quartermile',
      'pword' => 'brian123',
      'fname' => 'Brian O Conner',
      'type' => 'admin',
      'likes' => ['Dom\'s Sister', 'Cars', '']
    ],
    [
      'uname' => 'billionairems',
      'pword' => 'gates231',
      'fname' => 'Bill Gates',
      'type' => 'user',
      'likes' => ['Money', 'Money', 'Money']
    ],
    [
      'uname' => 'facebookcreator',
      'pword' => 'zuckerberg',
      'fname' => 'Mark Zuckerberg',
      'type' => 'user',
      'likes' => ['Social life']
    ],
    [
      'uname' => 'blitz',
      'pword' => 'instagramking',
      'fname' => 'Dan Bilzerian',
      'type' => 'admin',
      'likes' => ['Pictures']
    ],
    [
      'uname' => 'civilwar',
      'pword' => 'lincoln123',
      'fname' => 'Abraham Lincoln',
      'type' => 'user',
      'likes' => ['Gun', 'Bullet']
    ],
    [
      'uname' => 'kingluther',
      'pword' => 'martinking231',
      'fname' => 'Martin Luther King',
      'type' => 'user',
      'likes' => ['Equality', 'Black people', 'FREEDOM!']
    ]
  ];

 ?>
